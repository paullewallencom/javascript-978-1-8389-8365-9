
let arr = ["Steven", "Mary", "Simone", "Ari", "McKay", "James"];

let arrSort = [...arr];

arrSort.sort();

let arrReverse = Array.from(arr);

arrReverse.reverse();