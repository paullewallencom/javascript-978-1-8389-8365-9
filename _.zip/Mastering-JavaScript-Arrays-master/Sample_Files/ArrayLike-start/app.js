let arr = [1, 2, 3];

let obj = {
    1: 'one',
    2: 'two',
    3: 'three'
};

for (let val of obj) {
    console.log(val);
};
