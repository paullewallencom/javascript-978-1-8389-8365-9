
let scores = [90, 80, 75, 95, 60, 50, 0, 40, 100, 70];

let idx = 5;
console.log(scores[idx]);