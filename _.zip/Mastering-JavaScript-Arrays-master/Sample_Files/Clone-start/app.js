
let arr = ["Steven", "Mary", "Simone", "Ari", "McKay", "James"];
