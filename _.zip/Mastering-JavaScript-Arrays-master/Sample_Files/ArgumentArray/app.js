
let sumIt = function(...nums) {
    //let nums = [...arguments];
    console.log(Array.isArray(nums));
    console.log(nums);
};

sumIt(2,3,4,5,6,7);