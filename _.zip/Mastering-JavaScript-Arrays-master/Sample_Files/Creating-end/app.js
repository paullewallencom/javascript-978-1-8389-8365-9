
let arr1 = [];

let arr2 = [1, 2, 3, 4, true, "array", {one: 1}, [3, 5]];

let arr3 = new Array();

let arr4 = new Array(10);

let arr5 = [,,,,,,,,];

let arr6 = new Array(1,2,3,4,true);