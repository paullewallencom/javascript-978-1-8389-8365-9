
let arr = [1, 2, 3, 4, 5, 6];


//arr.copyWithin(2, 0, 2);

//arr.copyWithin(1, 2, 3);

//arr.copyWithin(2, 0);

arr.copyWithin(3, -1);

arr.copyWithin(0, 5, 6);