
nums = new Set([1, 2, "3", 4, "5"]);

