
//let scores = Array(10).fill(0);

let scores = [10,1,2,3,4,5,,,,].fill(0,0,3);