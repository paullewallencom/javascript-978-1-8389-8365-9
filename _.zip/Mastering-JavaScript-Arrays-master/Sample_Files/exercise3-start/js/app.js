//Add the contents of the methods array in the content.js file as bullet items inside the bullets div of methods.html. Use vanilla JavaScript.

