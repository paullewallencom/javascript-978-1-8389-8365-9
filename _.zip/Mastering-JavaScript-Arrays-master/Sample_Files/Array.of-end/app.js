
let arr = Array.of(5, 6, 7);

