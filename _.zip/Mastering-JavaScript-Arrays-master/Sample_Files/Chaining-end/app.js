
let arr = ["Steven", "Mary", "Simone", "Ari", "McKay", "James"];

let arrSort = [...arr].sort().toString();

let arrReverse = Array.from(arr).reverse().toString();