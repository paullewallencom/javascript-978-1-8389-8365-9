let obj = {
    "name": "Steven"
};

obj.lastName = "Hancock"

obj["score"] = 100;

obj[10] = 10;

let x = "complete";

obj.x = true;

obj[x] = true;

let i = {x: 10},
    j = {y: 20},
    obj2 = {};

obj2[i] = 100;
obj2[j] = 5;