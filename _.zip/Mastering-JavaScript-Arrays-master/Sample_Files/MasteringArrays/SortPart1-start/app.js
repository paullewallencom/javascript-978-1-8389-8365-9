
let arr = ["Steven", "Mary", "Simone", "ari", "McKay", "James"];

let arr2 = [15, -10, 500, 43, -25, 0, 323, 112];

