
let arr = [3, 15, 25, 6, 8, 12];

//for ([initialization];[condition];[increment]) {}