
let arr = [{
    firstName: "Steven",
    lastName: "Hancock",
    score: 90
},{
    firstName: "Lynette",
    lastName: "Jorgensen",
    score: 100
},{
    firstName: "Andrew",
    lastName: "Wilson",
    score: 71
},{
    firstName: "Annika",
    lastName: "Turner",
    score: 82
}];

