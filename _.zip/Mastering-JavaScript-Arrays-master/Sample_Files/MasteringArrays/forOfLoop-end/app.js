
let arr = [3, 15, 25, 6, 8, 12],
    total = 0;

for (let val of arr) {
    total += val;
};

console.log(total);