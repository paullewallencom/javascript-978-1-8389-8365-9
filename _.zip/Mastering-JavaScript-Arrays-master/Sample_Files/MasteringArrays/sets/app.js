
let set = new Set();

set.add(100);
set.add(5);
set.add(100);

let arr =  [1, 2, 4, 6, 8, 6, 7, 10, 2];

let set2 = new Set(arr);

let uniqArray = [...set2];