
let arr1 = [1, 2, 3, 4, true, "array", {one: 1}, [3, 5]];

console.log(arr1[6]);

arr1[6] = "steve";

arr1[8] = false;

arr1[20] = 55;