let array1 = [5, 10, 15, 20, 25],
    array2 = [2, 4, 6, 8, 10, 12],
    array3 = ["abc", "def", "ghi", "jkl"];
