let students = ["Steven", "Lynette", "Kaylie", "LJ", "Joshua", "Sarah", "Emily"],
    scores = [80, 90, 55, 60, 85, 95, 25];
