
let scores = [80, 50, 10, 100, 90, 80, 75];

let results = scores.every(function(val) {
    return val > 0;
});