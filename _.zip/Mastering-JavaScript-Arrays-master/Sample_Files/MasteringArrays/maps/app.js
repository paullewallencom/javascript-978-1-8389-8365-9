let i = {x: 10},
    j = {y: 20},
    obj2 = {};

obj2[i] = 100;
obj2[j] = 5;


let map = new Map();

map.set(i, 100);
map.set(j, 5);