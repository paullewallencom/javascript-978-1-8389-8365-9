
let arr1 = [1, 2, 3, 4, true, "array", {one: 1}, [3, 5]];
