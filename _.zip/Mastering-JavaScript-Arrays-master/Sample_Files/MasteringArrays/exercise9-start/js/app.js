/*
Create an Array of Arrays (multi-dimensional array) that will store a matrix for the product of even numbers up to and including 20. Here is a sample of the numbers the matrix will contain the product for. So in array[0][0] you should have 4 (2 * 2). array[0][1] and [1][0] should contain 8 (2 * 4) and so on.

   2   4   6   8   10   12   14   16   18   20
2
4      
6
8
10
12
14
16
18
20
*/

//Find out what number is in [9][9].