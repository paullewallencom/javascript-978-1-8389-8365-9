let stmt = "The best part of a sunset is the muted color that appears in anticipation of the deep reds, oranges and golds that will hopefully come later.";

let words = stmt.split(" ");

console.log(words.join(" "));

let arr = [1, 3, 4, 6, 2, 8];

let str = arr.join();