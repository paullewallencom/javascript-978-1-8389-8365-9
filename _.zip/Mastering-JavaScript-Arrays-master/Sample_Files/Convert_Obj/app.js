
let obj = {
    q1: 55,
    q2: 85,
    q3: 90,
    q4: 0
};

/*Object.keys();
Object.values();
Object.entries();*/