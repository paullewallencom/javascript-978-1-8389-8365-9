let array1 = [[5, 10], [15, 20], [25, 30, 35, 40]];

let newArray = array1.flat();


let strArray = ["The best part of a sunset", "is the muted color that appears", "in anticipation", "of", "the deep reds, oranges and golds that will hopefully come later."];

let strArraySplit = strArray.flatMap(val => val.split(" "));